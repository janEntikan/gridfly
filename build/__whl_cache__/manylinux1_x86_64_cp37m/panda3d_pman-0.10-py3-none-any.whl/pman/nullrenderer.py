class NullRenderer(object):
    '''Passthrough renderer that does not touch Panda3D state'''

    def __init__(self, _base):
        pass
