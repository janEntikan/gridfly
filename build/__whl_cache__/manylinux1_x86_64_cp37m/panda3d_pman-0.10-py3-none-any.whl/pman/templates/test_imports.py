def test_imports():
    import panda3d.core #pylint: disable=unused-import
